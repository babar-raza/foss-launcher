# Top Branches by Unique Commits

Generated: Sun, Feb  1, 2026  6:26:13 PM

## Top 15 Branches by PlusCount (commits not in main)

| Rank | Branch | PlusCount | MinusCount | UniqueCommits | Notes |
|------|--------|-----------|------------|---------------|-------|
| 1 | impl/tc300-wire-orchestrator-20260128 | 117 | 0 | 119 | Has unique commits not in main |
| 2 | fix/env-gates-20260128-1615 | 97 | 0 | 134 | Has unique commits not in main |
| 3 | fix/main-green-20260128-1505 | 95 | 0 | 131 | Has unique commits not in main |
| 4 | integrate/main-e2e-20260128-0837 | 92 | 0 | 127 | Has unique commits not in main |
| 5 | feat/TC-600-failure-recovery | 85 | 0 | 87 | Has unique commits not in main |
| 6 | feat/TC-590-security-handling | 80 | 0 | 82 | Has unique commits not in main |
| 7 | feat/TC-580-observability | 77 | 0 | 79 | Has unique commits not in main |
| 8 | feat/TC-560-determinism-harness | 74 | 0 | 76 | Has unique commits not in main |
| 9 | feat/TC-550-hugo-config | 71 | 0 | 73 | Has unique commits not in main |
| 10 | feat/TC-540-content-path-resolver | 69 | 0 | 71 | Has unique commits not in main |
| 11 | feat/TC-523-telemetry-metadata-endpoints | 66 | 0 | 68 | Has unique commits not in main |
| 12 | feat/TC-522-telemetry-batch-upload | 65 | 0 | 67 | Has unique commits not in main |
| 13 | feat/TC-521-telemetry-run-endpoints | 64 | 0 | 66 | Has unique commits not in main |
| 14 | feat/TC-520-telemetry-api-setup | 63 | 0 | 65 | Has unique commits not in main |
| 15 | feat/TC-530-cli-entrypoints | 62 | 0 | 64 | Has unique commits not in main |
