# Conflicts and Fixes

This file documents all merge conflicts and their resolutions.

## Format
- File path
- Conflict type
- Resolution rationale
- Commands used

---

(Entries will be added as conflicts occur)
