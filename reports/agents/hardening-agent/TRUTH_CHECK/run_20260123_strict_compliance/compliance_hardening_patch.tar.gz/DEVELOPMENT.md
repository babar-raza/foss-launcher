# Development Environment Setup

## Python Virtual Environment Policy (Binding)

**ALWAYS use `.venv` for all development work in this repository.**

### Quick Start

```bash
# Create and activate .venv
python -m venv .venv

# Windows
.venv\Scripts\activate

# Unix-like (Linux, macOS, WSL)
source .venv/bin/activate

# Install dependencies (preferred: deterministic)
make install-uv

# OR fallback (non-deterministic, not recommended)
make install
```

### Why .venv Only?

This repository enforces a strict `.venv` policy per [specs/00_environment_policy.md](specs/00_environment_policy.md):

1. **Consistency**: All developers and CI use the same virtual environment name
2. **Isolation**: Prevents conflicts with system Python packages
3. **Validation**: Gate 0 (`tools/validate_dotvenv_policy.py`) fails if `.venv` is not used
4. **No global installs**: Never install packages globally or in user site-packages

### Forbidden Alternatives

Do NOT use:
- `venv/`, `env/`, `.env/` (reserved for other purposes)
- Global Python packages
- User site-packages (`pip install --user`)
- `virtualenv` with custom names
- `conda` environments (not supported)

### Verification

Before starting work, always run:

```bash
python tools/validate_swarm_ready.py
```

Gate 0 will verify you're running from the correct `.venv`.

### CI/Automation

CI workflows and automation scripts MUST also use `.venv`:

```yaml
# Example GitHub Actions
- name: Setup Python environment
  run: |
    python -m venv .venv
    .venv/Scripts/python.exe -m pip install --upgrade pip uv
    .venv/Scripts/uv.exe sync --frozen
```

## See Also

- [specs/00_environment_policy.md](specs/00_environment_policy.md) - Full environment policy spec
- [specs/19_toolchain_and_ci.md](specs/19_toolchain_and_ci.md) - Toolchain and CI contracts
- [Makefile](Makefile) - Automated install targets
