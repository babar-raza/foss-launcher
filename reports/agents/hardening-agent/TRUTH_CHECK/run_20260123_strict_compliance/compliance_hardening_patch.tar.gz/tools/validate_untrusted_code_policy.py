#!/usr/bin/env python3
"""
Untrusted Code Policy Validator (Gate R - STUB)

Validates that ingested repo code is parse-only per Guarantee J.

NOTE: This is a STUB implementation. Full implementation requires:
- Static analysis of src/launch/** for subprocess calls
- Validation that cwd parameter never points to RUN_DIR/work/repo/
- Runtime wrapper enforcement

See: specs/34_strict_compliance_guarantees.md (Guarantee J)

Exit codes:
  0 - Static checks pass (basic validation)
  1 - Implementation incomplete (blocker in prod profile)
"""

import re
import sys
from pathlib import Path
from typing import List, Tuple


def scan_for_unsafe_subprocess(file_path: Path) -> List[Tuple[int, str]]:
    """
    Scan file for potentially unsafe subprocess calls.
    Returns list of (line_number, line_content).
    """
    violations = []

    try:
        content = file_path.read_text(encoding="utf-8")
    except Exception:
        return violations

    lines = content.split("\n")

    for i, line in enumerate(lines, 1):
        # Look for subprocess.run, subprocess.call, etc. with cwd parameter
        if "subprocess." in line and "cwd=" in line:
            violations.append((i, line.strip()))

    return violations


def main():
    """Stub validation routine."""
    script_dir = Path(__file__).parent
    repo_root = script_dir.parent

    print("=" * 70)
    print("UNTRUSTED CODE POLICY VALIDATION (Gate R - STUB)")
    print("=" * 70)
    print(f"Repository: {repo_root}")
    print()

    # Basic check: scan src/launch for subprocess calls
    launch_dir = repo_root / "src" / "launch"

    if not launch_dir.exists():
        print("Note: src/launch/ not yet created")
        print("  Policy will be enforced when implementation begins")
        print()
        print("=" * 70)
        print("RESULT: Untrusted code policy check skipped (no implementation yet)")
        print("=" * 70)
        return 0

    python_files = list(launch_dir.glob("**/*.py"))

    print(f"Scanning {len(python_files)} file(s) for subprocess calls...")
    print()

    violations = []
    for file_path in python_files:
        file_violations = scan_for_unsafe_subprocess(file_path)
        if file_violations:
            violations.append((file_path, file_violations))

    if violations:
        print("POTENTIAL VIOLATIONS DETECTED:")
        print()
        for file_path, file_violations in violations:
            relative = file_path.relative_to(repo_root)
            print(f"[WARN] {relative}")
            for line_num, line_content in file_violations:
                print(f"  Line {line_num}: {line_content[:100]}")
        print()

    print("WARNING: Untrusted code policy is NOT FULLY IMPLEMENTED")
    print()
    print("This gate requires full implementation:")
    print("  - Runtime wrapper in src/launch/util/subprocess.py")
    print("  - Validate cwd parameter never points to RUN_DIR/work/repo/")
    print("  - Block exec(), eval() on ingested code")
    print("  - Block dynamic imports from ingested repo")
    print("  - Add comprehensive tests")
    print()
    print("=" * 70)
    print("RESULT: Untrusted code policy implementation INCOMPLETE")
    print()
    print("Action required:")
    print("  - Implement subprocess wrapper with cwd validation")
    print("  - Add static analysis for eval/exec/import")
    print("  - Or accept this as blocker in prod profile")
    print("=" * 70)
    return 1


if __name__ == "__main__":
    sys.exit(main())
