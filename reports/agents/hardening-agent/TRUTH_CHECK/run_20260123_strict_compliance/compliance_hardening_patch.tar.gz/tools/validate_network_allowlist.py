#!/usr/bin/env python3
"""
Network Allowlist Validator (Gate N)

Validates that network allowlist exists per Guarantee D:
- config/network_allowlist.yaml exists (or .txt)

See: specs/34_strict_compliance_guarantees.md (Guarantee D)

Exit codes:
  0 - Network allowlist exists
  1 - Network allowlist missing or invalid
"""

import sys
from pathlib import Path


def main():
    """Main validation routine."""
    script_dir = Path(__file__).parent
    repo_root = script_dir.parent

    print("=" * 70)
    print("NETWORK ALLOWLIST VALIDATION (Gate N)")
    print("=" * 70)
    print(f"Repository: {repo_root}")
    print()

    # Check for allowlist file
    allowlist_yaml = repo_root / "config" / "network_allowlist.yaml"
    allowlist_txt = repo_root / "config" / "network_allowlist.txt"

    if allowlist_yaml.exists():
        print(f"Check: config/network_allowlist.yaml exists")
        print("  PASS: Network allowlist found")
        print()
        print("=" * 70)
        print("RESULT: Network allowlist is present")
        print("=" * 70)
        return 0
    elif allowlist_txt.exists():
        print(f"Check: config/network_allowlist.txt exists")
        print("  PASS: Network allowlist found")
        print()
        print("=" * 70)
        print("RESULT: Network allowlist is present")
        print("=" * 70)
        return 0
    else:
        print("Check: config/network_allowlist.yaml or .txt exists")
        print("  FAIL: Network allowlist not found")
        print()
        print("=" * 70)
        print("RESULT: Network allowlist validation FAILED")
        print()
        print("Required: Create config/network_allowlist.yaml (or .txt)")
        print()
        print("Example config/network_allowlist.yaml:")
        print("  allowed_hosts:")
        print("    - localhost")
        print("    - 127.0.0.1")
        print("    - api.github.com")
        print("    - *.aspose.com")
        print("=" * 70)
        return 1


if __name__ == "__main__":
    sys.exit(main())
