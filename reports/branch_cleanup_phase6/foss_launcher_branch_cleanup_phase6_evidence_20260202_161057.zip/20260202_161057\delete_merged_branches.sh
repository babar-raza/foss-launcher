#!/bin/bash
# Safe deletion of merged branches
# Using git branch -d (safe delete - will refuse if not fully merged)

echo "Starting safe deletion of merged branches..."
echo "Date: $(date)"
echo "========================================"
echo ""

# Delete branches (excluding main)
git branch -d \
  feat/TC-100-bootstrap-repo \
  feat/TC-200-schemas-and-io \
  feat/TC-201-emergency-mode \
  feat/TC-250-shared-libs-governance \
  feat/TC-300-orchestrator-langgraph \
  feat/TC-400-repo-scout \
  feat/TC-401-clone-resolve-shas \
  feat/TC-402-fingerprint \
  feat/TC-403-discover-docs \
  feat/TC-404-discover-examples \
  feat/TC-410-facts-builder \
  feat/TC-411-extract-claims \
  feat/TC-412-map-evidence \
  feat/TC-413-detect-contradictions \
  feat/TC-420-snippet-curator \
  feat/TC-421-extract-doc-snippets \
  feat/TC-422-extract-code-snippets \
  feat/TC-430-ia-planner \
  feat/TC-440-section-writer \
  feat/TC-450-linker-and-patcher \
  feat/TC-460-validator \
  feat/TC-470-fixer \
  feat/TC-480-pr-manager \
  feat/TC-500-clients-services \
  feat/TC-510-mcp-server-setup \
  feat/TC-511-mcp-tool-registration \
  feat/TC-512-mcp-tool-handlers \
  feat/TC-520-telemetry-api-setup \
  feat/TC-521-telemetry-run-endpoints \
  feat/TC-522-telemetry-batch-upload \
  feat/TC-523-telemetry-metadata-endpoints \
  feat/TC-530-cli-entrypoints \
  feat/TC-540-content-path-resolver \
  feat/TC-550-hugo-config \
  feat/TC-560-determinism-harness \
  feat/TC-570-extended-gates \
  feat/TC-571-perf-security-gates \
  feat/TC-580-observability \
  feat/TC-590-security-handling \
  feat/TC-600-failure-recovery \
  feat/golden-2pilots-20260201 \
  feat/tc902_hygiene_20260201 \
  feat/tc902_w4_impl_20260201 \
  fix/env-gates-20260128-1615 \
  fix/main-green-20260128-1505 \
  impl/tc300-wire-orchestrator-20260128 \
  integrate/consolidation_20260202_120555 \
  integrate/main-e2e-20260128-0837 \
  scratch/branch-consolidation-20260202_183400

echo ""
echo "========================================"
echo "Deletion complete"
echo "Date: $(date)"
