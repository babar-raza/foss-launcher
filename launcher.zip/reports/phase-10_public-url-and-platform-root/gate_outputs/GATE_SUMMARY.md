======================================================================
SWARM READINESS VALIDATION
======================================================================
Repository: C:\Users\prora\OneDrive\Documents\GitHub\foss-launcher

Running all validation gates...

======================================================================
Gate A1: Spec pack validation
======================================================================
SPEC PACK VALIDATION OK


======================================================================
Gate A2: Plans validation (zero warnings)
======================================================================
PLANS VALIDATION OK


======================================================================
Gate B: Taskcard validation + path enforcement
======================================================================
Validating taskcards in: C:\Users\prora\OneDrive\Documents\GitHub\foss-launcher

Found 39 taskcard(s) to validate

[OK] plans\taskcards\TC-100_bootstrap_repo.md
[OK] plans\taskcards\TC-200_schemas_and_io.md
[OK] plans\taskcards\TC-201_emergency_mode_manual_edits.md
[OK] plans\taskcards\TC-250_shared_libs_governance.md
[OK] plans\taskcards\TC-300_orchestrator_langgraph.md
[OK] plans\taskcards\TC-400_repo_scout_w1.md
[OK] plans\taskcards\TC-401_clone_and_resolve_shas.md
[OK] plans\taskcards\TC-402_repo_fingerprint_and_inventory.md
[OK] plans\taskcards\TC-403_frontmatter_contract_discovery.md
[OK] plans\taskcards\TC-404_hugo_site_context_build_matrix.md
[OK] plans\taskcards\TC-410_facts_builder_w2.md
[OK] plans\taskcards\TC-411_facts_extract_catalog.md
[OK] plans\taskcards\TC-412_evidence_map_linking.md
[OK] plans\taskcards\TC-413_truth_lock_compile_minimal.md
[OK] plans\taskcards\TC-420_snippet_curator_w3.md
[OK] plans\taskcards\TC-421_snippet_inventory_tagging.md
[OK] plans\taskcards\TC-422_snippet_selection_rules.md
[OK] plans\taskcards\TC-430_ia_planner_w4.md
[OK] plans\taskcards\TC-440_section_writer_w5.md
[OK] plans\taskcards\TC-450_linker_and_patcher_w6.md
[OK] plans\taskcards\TC-460_validator_w7.md
[OK] plans\taskcards\TC-470_fixer_w8.md
[OK] plans\taskcards\TC-480_pr_manager_w9.md
[OK] plans\taskcards\TC-500_clients_services.md
[OK] plans\taskcards\TC-510_mcp_server.md
[OK] plans\taskcards\TC-511_mcp_quickstart_url.md
[OK] plans\taskcards\TC-512_mcp_quickstart_github_repo_url.md
[OK] plans\taskcards\TC-520_pilots_and_regression.md
[OK] plans\taskcards\TC-522_pilot_e2e_cli.md
[OK] plans\taskcards\TC-523_pilot_e2e_mcp.md
[OK] plans\taskcards\TC-530_cli_entrypoints_and_runbooks.md
[OK] plans\taskcards\TC-540_content_path_resolver.md
[OK] plans\taskcards\TC-550_hugo_config_awareness_ext.md
[OK] plans\taskcards\TC-560_determinism_harness.md
[OK] plans\taskcards\TC-570_validation_gates_ext.md
[OK] plans\taskcards\TC-571_policy_gate_no_manual_edits.md
[OK] plans\taskcards\TC-580_observability_and_evidence_bundle.md
[OK] plans\taskcards\TC-590_security_and_secrets.md
[OK] plans\taskcards\TC-600_failure_recovery_and_backoff.md

======================================================================
SUCCESS: All 39 taskcards are valid


======================================================================
Gate C: Status board generation
======================================================================
Generating STATUS_BOARD from taskcards in: C:\Users\prora\OneDrive\Documents\GitHub\foss-launcher
Found 39 taskcard(s)

SUCCESS: Generated plans\taskcards\STATUS_BOARD.md
  Total taskcards: 39


======================================================================
Gate D: Markdown link integrity
======================================================================
Checking markdown links in: C:\Users\prora\OneDrive\Documents\GitHub\foss-launcher

Found 205 markdown file(s) to check

[OK] ASSUMPTIONS.md
[OK] CODE_OF_CONDUCT.md
[OK] CONTRIBUTING.md
[OK] DECISIONS.md
[OK] docs\architecture.md
[OK] docs\reference\local-telemetry-api.md
[OK] docs\reference\local-telemetry.md
[OK] GLOSSARY.md
[OK] OPEN_QUESTIONS.md
[OK] plans\00_orchestrator_master_prompt.md
[OK] plans\00_README.md
[OK] plans\_templates\taskcard.md
[OK] plans\acceptance_test_matrix.md
[OK] plans\implementation_master_checklist.md
[OK] plans\policies\no_manual_content_edits.md
[OK] plans\prompts\agent_kickoff.md
[OK] plans\prompts\agent_self_review.md
[OK] plans\prompts\orchestrator_handoff.md
[OK] plans\README.md
[OK] plans\swarm_coordination_playbook.md
[OK] plans\taskcards\00_TASKCARD_CONTRACT.md
[OK] plans\taskcards\INDEX.md
[OK] plans\taskcards\STATUS_BOARD.md
[OK] plans\taskcards\TC-100_bootstrap_repo.md
[OK] plans\taskcards\TC-200_schemas_and_io.md
[OK] plans\taskcards\TC-201_emergency_mode_manual_edits.md
[OK] plans\taskcards\TC-250_shared_libs_governance.md
[OK] plans\taskcards\TC-300_orchestrator_langgraph.md
[OK] plans\taskcards\TC-400_repo_scout_w1.md
[OK] plans\taskcards\TC-401_clone_and_resolve_shas.md
[OK] plans\taskcards\TC-402_repo_fingerprint_and_inventory.md
[OK] plans\taskcards\TC-403_frontmatter_contract_discovery.md
[OK] plans\taskcards\TC-404_hugo_site_context_build_matrix.md
[OK] plans\taskcards\TC-410_facts_builder_w2.md
[OK] plans\taskcards\TC-411_facts_extract_catalog.md
[OK] plans\taskcards\TC-412_evidence_map_linking.md
[OK] plans\taskcards\TC-413_truth_lock_compile_minimal.md
[OK] plans\taskcards\TC-420_snippet_curator_w3.md
[OK] plans\taskcards\TC-421_snippet_inventory_tagging.md
[OK] plans\taskcards\TC-422_snippet_selection_rules.md
[OK] plans\taskcards\TC-430_ia_planner_w4.md
[OK] plans\taskcards\TC-440_section_writer_w5.md
[OK] plans\taskcards\TC-450_linker_and_patcher_w6.md
[OK] plans\taskcards\TC-460_validator_w7.md
[OK] plans\taskcards\TC-470_fixer_w8.md
[OK] plans\taskcards\TC-480_pr_manager_w9.md
[OK] plans\taskcards\TC-500_clients_services.md
[OK] plans\taskcards\TC-510_mcp_server.md
[OK] plans\taskcards\TC-511_mcp_quickstart_url.md
[OK] plans\taskcards\TC-512_mcp_quickstart_github_repo_url.md
[OK] plans\taskcards\TC-520_pilots_and_regression.md
[OK] plans\taskcards\TC-522_pilot_e2e_cli.md
[OK] plans\taskcards\TC-523_pilot_e2e_mcp.md
[OK] plans\taskcards\TC-530_cli_entrypoints_and_runbooks.md
[OK] plans\taskcards\TC-540_content_path_resolver.md
[OK] plans\taskcards\TC-550_hugo_config_awareness_ext.md
[OK] plans\taskcards\TC-560_determinism_harness.md
[OK] plans\taskcards\TC-570_validation_gates_ext.md
[OK] plans\taskcards\TC-571_policy_gate_no_manual_edits.md
[OK] plans\taskcards\TC-580_observability_and_evidence_bundle.md
[OK] plans\taskcards\TC-590_security_and_secrets.md
[OK] plans\taskcards\TC-600_failure_recovery_and_backoff.md
[OK] plans\traceability_matrix.md
[OK] README.md
[OK] reports\phase-0_discovery\gap_analysis.md
[OK] reports\phase-0_discovery\inventory.md
[OK] reports\phase-0_discovery\phase-0_self_review.md
[OK] reports\phase-0_discovery\standardization_proposal.md
[OK] reports\phase-10_public-url-and-platform-root\gate_outputs\GATE_SUMMARY.md
[OK] reports\phase-1_spec-hardening\change_log.md
[OK] reports\phase-1_spec-hardening\diff_manifest.md
[OK] reports\phase-1_spec-hardening\phase-1_self_review.md
[OK] reports\phase-1_spec-hardening\spec_quality_gates.md
[OK] reports\phase-2_plan-taskcard-hardening\change_log.md
[OK] reports\phase-2_plan-taskcard-hardening\diff_manifest.md
[OK] reports\phase-2_plan-taskcard-hardening\phase-2_self_review.md
[OK] reports\phase-2_plan-taskcard-hardening\taskcard_coverage.md
[OK] reports\phase-3_final-readiness\final_diff_manifest.md
[OK] reports\phase-3_final-readiness\orchestrator_review.md
[OK] reports\phase-3_final-readiness\readiness_checklist.md
[OK] reports\phase-4_swarm-hardening\change_log.md
[OK] reports\phase-4_swarm-hardening\diff_manifest.md
[OK] reports\phase-4_swarm-hardening\self_review_12d.md
[OK] reports\phase-5_swarm-hardening\change_log.md
[OK] reports\phase-5_swarm-hardening\diff_manifest.md
[OK] reports\phase-5_swarm-hardening\errata.md
[OK] reports\phase-5_swarm-hardening\gate_outputs\GATE_SUMMARY.md
[OK] reports\phase-5_swarm-hardening\self_review_12d.md
[OK] reports\phase-6_1_platform-completeness\change_log.md
[OK] reports\phase-6_1_platform-completeness\diff_manifest.md
[OK] reports\phase-6_1_platform-completeness\gate_outputs\GATE_SUMMARY.md
[OK] reports\phase-6_1_platform-completeness\self_review_12d.md
[OK] reports\phase-6_2_platform-completeness\change_log.md
[OK] reports\phase-6_2_platform-completeness\diff_manifest.md
[OK] reports\phase-6_2_platform-completeness\self_review_12d.md
[OK] reports\phase-6_2_to_8_orchestrator\baseline_inventory.md
[OK] reports\phase-6_2_to_8_orchestrator\gate_outputs\FINAL_GATE_SUMMARY.md
[OK] reports\phase-6_2_to_8_orchestrator\global_change_log.md
[OK] reports\phase-6_2_to_8_orchestrator\global_diff_manifest.md
[OK] reports\phase-6_platform-layout\change_log.md
[OK] reports\phase-6_platform-layout\design_notes.md
[OK] reports\phase-6_platform-layout\diff_manifest.md
[OK] reports\phase-6_platform-layout\self_review_12d.md
[OK] reports\phase-7_taskcard_coverage_audit\coverage_matrix.md
[OK] reports\phase-9_mcp-github-and-pilots\change_log.md
[OK] reports\phase-9_mcp-github-and-pilots\diff_manifest.md
[OK] reports\phase-9_mcp-github-and-pilots\gate_outputs\GATE_SUMMARY.md
[OK] reports\phase-9_mcp-github-and-pilots\self_review_12d.md
[OK] reports\README.md
[OK] reports\sanity_checks.md
[OK] reports\swarm_allowed_paths_audit.md
[OK] reports\swarm_readiness_review.md
[OK] reports\templates\agent_report.md
[OK] reports\templates\orchestrator_master_review.md
[OK] reports\templates\self_review_12d.md
[OK] SECURITY.md
[OK] specs\00_overview.md
[OK] specs\01_system_contract.md
[OK] specs\02_repo_ingestion.md
[OK] specs\03_product_facts_and_evidence.md
[OK] specs\04_claims_compiler_truth_lock.md
[OK] specs\05_example_curation.md
[OK] specs\06_page_planning.md
[OK] specs\07_section_templates.md
[OK] specs\08_patch_engine.md
[OK] specs\09_validation_gates.md
[OK] specs\10_determinism_and_caching.md
[OK] specs\11_state_and_events.md
[OK] specs\12_pr_and_release.md
[OK] specs\13_pilots.md
[OK] specs\14_mcp_endpoints.md
[OK] specs\15_llm_providers.md
[OK] specs\16_local_telemetry_api.md
[OK] specs\17_github_commit_service.md
[OK] specs\18_site_repo_layout.md
[OK] specs\19_toolchain_and_ci.md
[OK] specs\20_rulesets_and_templates_registry.md
[OK] specs\21_worker_contracts.md
[OK] specs\22_navigation_and_existing_content_update.md
[OK] specs\23_claim_markers.md
[OK] specs\24_mcp_tool_schemas.md
[OK] specs\25_frameworks_and_dependencies.md
[OK] specs\26_repo_adapters_and_variability.md
[OK] specs\27_universal_repo_handling.md
[OK] specs\28_coordination_and_handoffs.md
[OK] specs\29_project_repo_structure.md
[OK] specs\30_site_and_workflow_repos.md
[OK] specs\31_hugo_config_awareness.md
[OK] specs\32_platform_aware_content_layout.md
[OK] specs\33_public_url_mapping.md
[OK] specs\blueprint.md
[OK] specs\examples\frontmatter_models.md
[OK] specs\patches\16_local_telemetry_api.patch.md
[OK] specs\pilot-blueprint.md
[OK] specs\pilots\pilot-aspose-3d-foss-python\notes.md
[OK] specs\pilots\pilot-aspose-note-foss-python\notes.md
[OK] specs\pilots\README.md
[OK] specs\README.md
[OK] specs\reference\hugo-configs\README.md
[OK] specs\state-graph.md
[OK] specs\state-management.md
[OK] specs\templates\blog.aspose.org\cells\__PLATFORM__\__POST_SLUG__\index.variant-minimal.md
[OK] specs\templates\blog.aspose.org\cells\__PLATFORM__\__POST_SLUG__\index.variant-standard.md
[OK] specs\templates\blog.aspose.org\cells\__PLATFORM__\README.md
[OK] specs\templates\blog.aspose.org\cells\__POST_SLUG__\index.variant-enhanced-keywords.md
[OK] specs\templates\blog.aspose.org\cells\__POST_SLUG__\index.variant-enhanced-seotitle.md
[OK] specs\templates\blog.aspose.org\cells\__POST_SLUG__\index.variant-enhanced.md
[OK] specs\templates\blog.aspose.org\cells\__POST_SLUG__\index.variant-minimal.md
[OK] specs\templates\blog.aspose.org\cells\__POST_SLUG__\index.variant-standard.md
[OK] specs\templates\blog.aspose.org\cells\__POST_SLUG__\index.variant-steps-usecases.md
[OK] specs\templates\blog.aspose.org\cells\README.md
[OK] specs\templates\docs.aspose.org\cells\__LOCALE__\__PLATFORM__\__SECTION_PATH__\_index.variant-minimal.md
[OK] specs\templates\docs.aspose.org\cells\__LOCALE__\__PLATFORM__\__SECTION_PATH__\_index.variant-standard.md
[OK] specs\templates\docs.aspose.org\cells\__LOCALE__\__PLATFORM__\_index.md
[OK] specs\templates\docs.aspose.org\cells\__LOCALE__\__PLATFORM__\README.md
[OK] specs\templates\docs.aspose.org\cells\__LOCALE__\__SECTION_PATH__\_index.variant-sidebar.md
[OK] specs\templates\docs.aspose.org\cells\__LOCALE__\__SECTION_PATH__\_index.variant-weight.md
[OK] specs\templates\docs.aspose.org\cells\__LOCALE__\_index.md
[OK] specs\templates\docs.aspose.org\cells\README.md
[OK] specs\templates\kb.aspose.org\cells\__LOCALE__\__CONVERTER_SLUG__\__TOPIC_SLUG__.variant-productname-usecases.md
[OK] specs\templates\kb.aspose.org\cells\__LOCALE__\__CONVERTER_SLUG__\__TOPIC_SLUG__.variant-steps-aliases.md
[OK] specs\templates\kb.aspose.org\cells\__LOCALE__\__CONVERTER_SLUG__\__TOPIC_SLUG__.variant-steps-usecases-lastmod.md
[OK] specs\templates\kb.aspose.org\cells\__LOCALE__\__CONVERTER_SLUG__\__TOPIC_SLUG__.variant-steps-usecases.md
[OK] specs\templates\kb.aspose.org\cells\__LOCALE__\__CONVERTER_SLUG__\__TOPIC_SLUG__.variant-steps.md
[OK] specs\templates\kb.aspose.org\cells\__LOCALE__\__CONVERTER_SLUG__\_index.variant-no-draft.md
[OK] specs\templates\kb.aspose.org\cells\__LOCALE__\__CONVERTER_SLUG__\_index.variant-with-draft.md
[OK] specs\templates\kb.aspose.org\cells\__LOCALE__\__PLATFORM__\__TOPIC_SLUG__.variant-standard.md
[OK] specs\templates\kb.aspose.org\cells\__LOCALE__\__PLATFORM__\_index.md
[OK] specs\templates\kb.aspose.org\cells\__LOCALE__\__PLATFORM__\README.md
[OK] specs\templates\kb.aspose.org\cells\__LOCALE__\_index.md
[OK] specs\templates\kb.aspose.org\cells\README.md
[OK] specs\templates\products.aspose.org\cells\__LOCALE__\__CONVERTER_SLUG__\__FORMAT_SLUG__.md
[OK] specs\templates\products.aspose.org\cells\__LOCALE__\__CONVERTER_SLUG__\_index.md
[OK] specs\templates\products.aspose.org\cells\__LOCALE__\__PLATFORM__\__CONVERTER_SLUG__\_index.md
[OK] specs\templates\products.aspose.org\cells\__LOCALE__\__PLATFORM__\_index.md
[OK] specs\templates\products.aspose.org\cells\__LOCALE__\__PLATFORM__\README.md
[OK] specs\templates\products.aspose.org\cells\__LOCALE__\_index.md
[OK] specs\templates\products.aspose.org\cells\README.md
[OK] specs\templates\README.md
[OK] specs\templates\reference.aspose.org\cells\__LOCALE__\__PLATFORM__\__REFERENCE_SLUG__.md
[OK] specs\templates\reference.aspose.org\cells\__LOCALE__\__PLATFORM__\_index.md
[OK] specs\templates\reference.aspose.org\cells\__LOCALE__\__PLATFORM__\README.md
[OK] specs\templates\reference.aspose.org\cells\__LOCALE__\__REFERENCE_SLUG__.md
[OK] specs\templates\reference.aspose.org\cells\README.md
[OK] TRACEABILITY_MATRIX.md

======================================================================
SUCCESS: All internal links valid (205 files checked)


======================================================================
Gate E: Allowed paths audit (zero violations + zero critical overlaps)
======================================================================
Auditing allowed_paths in all taskcards...

Found 39 taskcard(s)

Report generated: reports\swarm_allowed_paths_audit.md

Summary:
  Total unique paths: 160
  Overlapping paths: 0
  Critical overlaps: 0
  Shared lib violations: 0

[OK] No violations detected


======================================================================
Gate F: Platform layout consistency (V2)
======================================================================
Platform Layout Consistency Validation (V2)
======================================================================

[OK] Schema includes target_platform and layout_mode
[OK] Binding spec exists (32_platform_aware_content_layout.md)
[OK] TC-540 mentions platform + V2 paths
[OK] Example configs updated with platform fields
[OK] Key specs updated for V2 layout
[OK] Templates hierarchy has __PLATFORM__ folders
[OK] Templates README documents V1 and V2
[OK] Config templates have platform fields
[OK] Products V2 path uses /{locale}/{platform}/ format
[OK] Products templates V2 use __LOCALE__/__PLATFORM__ order

======================================================================
SUCCESS: Platform layout consistency checks passed
======================================================================


======================================================================
Gate G: Pilots contract (canonical path consistency)
======================================================================
======================================================================
PILOTS CONTRACT VALIDATION
======================================================================
Repository: C:\Users\prora\OneDrive\Documents\GitHub\foss-launcher

Check 1: Verifying specs/13_pilots.md defines canonical location...
  PASS: specs/13_pilots.md references specs/pilots/ as canonical

Check 2: Verifying required pilot files exist...
  PASS: All required files present for 2 pilot(s)

Check 3: Checking for conflicting canonical path claims...
  PASS: No conflicting canonical path claims found

======================================================================
RESULT: All pilots contract checks passed
======================================================================


======================================================================
Gate H: MCP contract (quickstart tools in specs)
======================================================================
======================================================================
MCP CONTRACT VALIDATION
======================================================================
Repository: C:\Users\prora\OneDrive\Documents\GitHub\foss-launcher

Check 1: Verifying specs/14_mcp_endpoints.md...
  PASS: Both quickstart tools documented in MCP endpoints spec

Check 2: Verifying specs/24_mcp_tool_schemas.md...
  PASS: Both quickstart tools have schema sections

Check 3: Verifying taskcards exist for both quickstart tools...
  PASS: TC-511 and TC-512 exist and reference correct tool names

======================================================================
RESULT: All MCP contract checks passed
======================================================================


======================================================================
GATE SUMMARY
======================================================================

[PASS] Gate A1: Spec pack validation
[PASS] Gate A2: Plans validation (zero warnings)
[PASS] Gate B: Taskcard validation + path enforcement
[PASS] Gate C: Status board generation
[PASS] Gate D: Markdown link integrity
[PASS] Gate E: Allowed paths audit (zero violations + zero critical overlaps)
[PASS] Gate F: Platform layout consistency (V2)
[PASS] Gate G: Pilots contract (canonical path consistency)
[PASS] Gate H: MCP contract (quickstart tools in specs)

======================================================================
SUCCESS: All gates passed - repository is swarm-ready
======================================================================
