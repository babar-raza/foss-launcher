"""Unit tests for resolvers."""
