"""Tests for HTTP clients."""
