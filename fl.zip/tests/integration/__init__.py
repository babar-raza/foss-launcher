"""Integration tests for foss-launcher."""
