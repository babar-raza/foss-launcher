---
# Template: reference entry (layout: "reference-single")
# Source pattern: content/reference.aspose.org/cells/{locale}/{reference}.md
linkTitle: "__LINK_TITLE__"
title: "__TITLE__"
description: "__DESCRIPTION__"
summary: "__SUMMARY__"
categories:
  - "__CATEGORY_1__"
layout: "reference-single"
---
__BODY_OVERVIEW__

## Namespace and assembly

__BODY_NAMESPACE__

## Syntax

```text
__BODY_SIGNATURE__
```

## Parameters

__BODY_PARAMETERS__

## Returns

__BODY_RETURNS__

## Remarks

__BODY_REMARKS__

## Examples

__BODY_CODE_SAMPLES__

## See also

__BODY_SEE_ALSO__
