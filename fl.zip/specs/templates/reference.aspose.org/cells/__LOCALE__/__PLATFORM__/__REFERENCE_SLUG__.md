---
# Template: V2 reference module page (platform-aware)
# Source pattern: content/reference.aspose.org/{family}/{locale}/{platform}/{reference}.md
title: "__TITLE__"
linktitle: "__LINKTITLE__"
type: docs
url: "/reference/__FAMILY__/__LOCALE__/__PLATFORM__/__REFERENCE_SLUG__/"
weight: __WEIGHT__
---

## Purpose

__BODY_PURPOSE__

## Key Symbols

__BODY_KEY_SYMBOLS__

## Usage Snippet

```__PLATFORM__
__BODY_USAGE_SNIPPET__
```

## See Also

__BODY_SEE_ALSO__
