# pilot-aspose-3d-foss-python

## What to record here
- repo archetype and structure notes
- example/doc discovery quirks
- any known unavoidable limitations
- expected launch_tier and template variants

## Surrogate Pilot (TC-520 / TC-522)

**SURROGATE PILOT:** github_repo_url substituted because planned pilot repo unavailable.

- Original (planned): `https://github.com/Aspose/aspose-3d-foss-python`
- Surrogate (actual): `https://github.com/aspose-3d/Aspose.3D-for-Python-via-.NET`
- Reason: Original repository not found (404)
- Substitution date: 2026-01-29
- All refs pinned to verified commit SHAs

