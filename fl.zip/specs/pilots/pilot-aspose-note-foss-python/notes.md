# pilot-aspose-note-foss-python

## What to record here
- repo archetype and structure notes
- example/doc discovery quirks
- any known unavoidable limitations
- expected launch_tier and template variants

