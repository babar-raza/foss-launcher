"""Telemetry API routes package."""
