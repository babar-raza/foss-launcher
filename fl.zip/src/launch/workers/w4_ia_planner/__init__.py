"""
Worker W4: IA Planner

Plans information architecture for documentation pages per
specs/21_worker_contracts.md.

This package is a structural placeholder per DEC-005 (DECISIONS.md).
Implementation will be provided by TC-430 taskcard.
"""

__all__ = []
