"""Shared utilities for worker implementations."""
