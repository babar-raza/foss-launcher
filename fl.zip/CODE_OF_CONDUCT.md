# Code of Conduct

Be respectful.

- Assume good intent.
- Focus on the work, not the person.
- Keep discussions professional.

Maintainers may moderate or remove content that violates these principles.
